How to use
Step 1 - Unzip the folder MagazineStore
step 2 - Go to Inside this folder MagazineStore\MagazineStore\bin\Debug\netcoreapp3.1
Step 3 - run the console exe (MagazineStore.exe)

you can see the output on the console
 