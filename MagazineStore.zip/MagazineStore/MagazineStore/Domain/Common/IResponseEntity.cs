﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MagazineStore.Domain.Common
{
    public interface IResponseEntity
    {
    }
}
