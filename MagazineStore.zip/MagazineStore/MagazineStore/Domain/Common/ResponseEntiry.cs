﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MagazineStore.Domain.Common
{
    public class ResponseEntiry: IResponseEntity
    {
        public ResponseEntiry()
        {
        }

        public ResponseEntiry(string _status,string _data =null, string _message=null)
        {
            status = _status;
            message = _message;
            data = _data;
        }


        public object data { get; set; }

        public string status { get; set; }
        public string message { get; set; }


    }
}
