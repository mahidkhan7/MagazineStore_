﻿using Hangfire.Server;
using MagazineStore.Application.Interfaces;
using MagazineStore.Application.Models;
using MagazineStore.Domain.Common;
using MagazineStore.Infrastructure;
using MagazineStore.Infrastructure.Configuration;
using MagazineStore.Infrastructure.Interface;
using MagazineStore.Infrastructure.Services;
using MagazineStore.Infrastructure.Services.Security;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using System.Linq;
using System.Threading;

namespace MagazineStore
{
    class Program
    {
        IMagazineService _magazineService;
        IOptions<MagazineConfig> _magazineConfig;

        public Program(IMagazineService magazineService, IOptions<MagazineConfig> magazineConfig)
        {
            _magazineService = magazineService;
            _magazineConfig = magazineConfig;
        }
        static void UnhandledExceptionTrapper(object sender, UnhandledExceptionEventArgs e)
        {
            Console.WriteLine(e.ExceptionObject.ToString());
            Console.WriteLine("Press Enter to continue");
            Console.ReadLine();
            Environment.Exit(1);
        }
        static void Main(string[] args)
        {

            #region Bootstarping the app and dependencies
            System.AppDomain.CurrentDomain.UnhandledException += UnhandledExceptionTrapper;

            var serviceProvider = new ServiceCollection()
                 .AddTransient<IMagazineAPI, MagazineAPI>()
                 .AddTransient<IMagazineService, MagazineService>()
                 .AddHttpClient()
                 .AddSingleton<ITokenHandler, TokenHandler>();

            IConfiguration configuration = new ConfigurationBuilder()
                 .SetBasePath(Directory.GetCurrentDirectory())
                 .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                 .AddEnvironmentVariables()
                 .AddCommandLine(args)
                 .Build();

            serviceProvider.Configure<MagazineConfig>(configuration.GetSection("MagazineConfig"));
            var services = serviceProvider.BuildServiceProvider();

            #endregion



            Program p = new Program(services.GetService<IMagazineService>(), services.GetService<IOptions<MagazineConfig>>());

            //Get all categories API
            CategoriesModel categories = p.GetAllCategories(services).Result;
           
            //Magazine by category API
            List<MagazineByCategoryModel> magazineList = new List<MagazineByCategoryModel>();
            foreach (string str in categories.data)
            {
                MagazineByCategoryModel magazineByCategory = p.GeAtllMagazineByCategories(services, str).Result;
               magazineList.Add(magazineByCategory);
            }

            //All Subscriber API
            SubscriberModel subscribers = p.GetSubscribers(services).Result;
            //Checking subscriber belongs to each category or not
            List<string> subscriberIDForAnswer = new List<string>();
            foreach (Subscriber subs in subscribers.data)
            {
                if (IsSubbscriberBelongToEachCategory(subs, magazineList))
                {
                    subscriberIDForAnswer.Add(subs.id);
                }
            }


            // calling answer api
            AnswersModel answerModel = p.GetAnswers(services, subscriberIDForAnswer).Result;


            Console.WriteLine(JsonConvert.SerializeObject(answerModel));
            Console.Read();
        }

        #region Custom Methods
        async Task<CategoriesModel> GetAllCategories(IServiceProvider service)
        {
            CategoriesModel categoriesResult = new CategoriesModel();
            MagazineGetAllCategories model = new MagazineGetAllCategories
            {
                Token = service.GetService<ITokenHandler>().Token
            };
            IResponseEntity responseCategory = await _magazineService.GeAllCategories(model);
            ResponseEntiry categoryEntity = (ResponseEntiry)responseCategory;
            if (categoryEntity != null && categoryEntity.data != null)
            {
                categoriesResult = JsonConvert.DeserializeObject<CategoriesModel>(categoryEntity.data.ToString());
            }
            return categoriesResult;
        }
        async Task<SubscriberModel> GetSubscribers(IServiceProvider service)
        {
            SubscriberModel subscriberResult = new SubscriberModel();
            MagazineGetSubcribers model = new MagazineGetSubcribers
            {
                Token = service.GetService<ITokenHandler>().Token
            };
            IResponseEntity responseSubscriber = await _magazineService.GeSubcribers(model);
            ResponseEntiry subscriberEntity = (ResponseEntiry)responseSubscriber;
            if (subscriberEntity != null && subscriberEntity.data != null)
            {
                subscriberResult = JsonConvert.DeserializeObject<SubscriberModel>(subscriberEntity.data.ToString());
            }
            return subscriberResult;
        }
        async Task<MagazineByCategoryModel> GeAtllMagazineByCategories(IServiceProvider service, string category)
        {
            MagazineByCategoryModel magazineCategoriesResult = new MagazineByCategoryModel();
            MagazineGetCategories model = new MagazineGetCategories
            {
                Token = service.GetService<ITokenHandler>().Token,
                Category = category
            };
            IResponseEntity responseMagazineCategory = await _magazineService.GeMagazineByCateogry(model);
            ResponseEntiry magazineCateforyEntity = (ResponseEntiry)responseMagazineCategory;
            if (magazineCateforyEntity != null && magazineCateforyEntity.data != null)
            {
                magazineCategoriesResult = JsonConvert.DeserializeObject<MagazineByCategoryModel>(magazineCateforyEntity.data.ToString());
            }
            return magazineCategoriesResult;
        }
        async Task<AnswersModel> GetAnswers(IServiceProvider service, List<string> subscriber)
        {
            AnswersModel answerResult = new AnswersModel();
            MagazineGetAnswers model = new MagazineGetAnswers
            {
                Token = service.GetService<ITokenHandler>().Token,
                subscribers = subscriber
            };
            IResponseEntity responseAnswers = await _magazineService.GeAnswers(model);
            ResponseEntiry answerEntity = (ResponseEntiry)responseAnswers;
            if (answerEntity != null && answerEntity.data != null)
            {
                answerResult = JsonConvert.DeserializeObject<AnswersModel>(answerEntity.data.ToString());
            }
            return answerResult;
        }
        static bool IsSubbscriberBelongToEachCategory(Subscriber subs, List<MagazineByCategoryModel> magazineList)
        {
            var flag = true;
            foreach (MagazineByCategoryModel model in magazineList)
            {
                if (model.data.Where(x => subs.magazineIds.Contains(x.id)).Count()<= 0)
                {
                    flag = false;
                }
            }
            return flag;
        }
        #endregion
    }
}
