﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MagazineStore.Application.Models
{
    public class MagazineGetCategories
    {
        public string Token { get; set; }
        public string Category { get; set; }
    }
}
