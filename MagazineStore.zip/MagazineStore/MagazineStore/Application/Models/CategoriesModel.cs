﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MagazineStore.Application.Models
{
    public class CategoriesModel
    {
        public List<string> data { get; set; }
        public bool success { get; set; }
        public string token { get; set; }
    }
}
