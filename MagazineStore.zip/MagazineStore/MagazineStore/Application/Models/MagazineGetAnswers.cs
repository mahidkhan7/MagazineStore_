﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MagazineStore.Application.Models
{
    public class MagazineGetAnswers
    {
        public string Token { get; set; }
        public List<string> subscribers { get; set; }

    }
}
