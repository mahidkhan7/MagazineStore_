﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MagazineStore.Application.Models
{
    public class AnswerData
    {
        public string totalTime { get; set; }
        public bool answerCorrect { get; set; }
        public List<string> shouldBe { get; set; }
    }

    public class AnswersModel
    {
        public AnswerData data { get; set; }
        public bool success { get; set; }
        public string token { get; set; }
        public string message { get; set; }
    }


}
