﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MagazineStore.Application.Models
{
    
    public class Subscriber
    {
        public string id { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public List<int> magazineIds { get; set; }
    }

    public class SubscriberModel
    {
        public List<Subscriber> data { get; set; }
        public bool success { get; set; }
        public string token { get; set; }
    }

}
