﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MagazineStore.Infrastructure.Models
{
    public class TokenDetails
    {
        public bool success { get; set; }
        public string token { get; set; }
    }
}
