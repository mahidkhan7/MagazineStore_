﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MagazineStore.Infrastructure.Services.Security
{
   public interface ITokenHandler
    {
        string Token { get; }
        Task<string> CreateTokenAsync();
    }
}
