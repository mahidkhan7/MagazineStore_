﻿using MagazineStore.Infrastructure.Configuration;
using MagazineStore.Infrastructure.Models;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MagazineStore.Infrastructure.Services.Security
{
    public class TokenHandler : ITokenHandler
    {

        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IOptions<MagazineConfig> _configSetting;

        public string Token { get; private set; }

        public TokenHandler(IHttpClientFactory httpClientFactory, IOptions<MagazineConfig> configSetting)
        {
            _httpClientFactory = httpClientFactory;
            _configSetting = configSetting;
        }
        public async Task<string> CreateTokenAsync()
        {
            try
            {
                var httpClient = _httpClientFactory.CreateClient();

                var result = await httpClient.GetAsync(_configSetting.Value.BaseURL + _configSetting.Value.GenerateTokenURL);
                var response = result.IsSuccessStatusCode ? await result.Content.ReadAsStringAsync() : null;

                if (!string.IsNullOrEmpty(response))
                {
                    TokenDetails tokenDetails = JsonConvert.DeserializeObject<TokenDetails>(response);
                    Token = tokenDetails.token;
                }
                return Token;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
