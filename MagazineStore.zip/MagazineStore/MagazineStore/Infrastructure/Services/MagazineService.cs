﻿using MagazineStore.Application.Interfaces;
using MagazineStore.Application.Models;
using MagazineStore.Domain.Common;
using MagazineStore.Infrastructure.Configuration;
using MagazineStore.Infrastructure.Interface;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MagazineStore.Infrastructure.Services
{
    public class MagazineService : IMagazineService
    {
        protected readonly IMagazineAPI _magazineAPI;
        protected readonly IOptions<MagazineConfig> _magazineConfig;

        public MagazineService(IMagazineAPI magazineAPI, IOptions<MagazineConfig> magazineConfig)
        {
            _magazineAPI = magazineAPI;
            _magazineConfig = magazineConfig;
        }

        public async Task<IResponseEntity> GeAllCategories(MagazineGetAllCategories model)
        {
            string URL = _magazineConfig.Value.BaseURL + _magazineConfig.Value.CategoriesURL;
            IResponseEntity response = await _magazineAPI.MagazineApiOperation(URL, HttpVerbEnum.GET.ToString(), null);
            return response;
        }

        public async Task<IResponseEntity> GeAnswers(MagazineGetAnswers model)
        {
            string URL = _magazineConfig.Value.BaseURL + _magazineConfig.Value.AnswerURL;
            IResponseEntity response = await _magazineAPI.MagazineApiOperation(URL, HttpVerbEnum.POST.ToString(), model);
            return response;
        }

        public async Task<IResponseEntity> GeMagazineByCateogry(MagazineGetCategories model)
        {
            string URL = _magazineConfig.Value.BaseURL + string.Format(_magazineConfig.Value.MagazinesByCategoryURL, "{0}", model.Category);
            IResponseEntity response = await _magazineAPI.MagazineApiOperation(URL, HttpVerbEnum.GET.ToString(), null);
            return response;
        }

        public async Task<IResponseEntity> GeSubcribers(MagazineGetSubcribers model)
        {
            string URL = _magazineConfig.Value.BaseURL + _magazineConfig.Value.SubscriberURL;
            IResponseEntity response = await _magazineAPI.MagazineApiOperation(URL, HttpVerbEnum.GET.ToString(), null);
            return response;
        }
    }
}
