﻿using MagazineStore.Application.Interfaces;
using MagazineStore.Infrastructure.Services.Security;
using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;

namespace MagazineStore.Infrastructure.Services
{
    public class BaseAPIService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ITokenHandler _tokenHandler;

        public BaseAPIService(IHttpClientFactory httpClientFactory, ITokenHandler tokenHandler)
        {
            _httpClientFactory = httpClientFactory;
            _tokenHandler = tokenHandler;
        }


        public async Task<HttpResponseMessage> RequestAsync(HttpRequestMessage request)
        {
            try
            {
                HttpRequestMessage requestMessage = request;
                if (_tokenHandler.Token != null)
                {
                    requestMessage = new HttpRequestMessage
                    {
                        Method = request.Method,
                        RequestUri = new Uri(string.Format(HttpUtility.UrlDecode(Convert.ToString(request.RequestUri.AbsoluteUri)), _tokenHandler.Token)),
                        Content = request.Content
                    };


                    HttpClient httpClient = _httpClientFactory.CreateClient();
                    await Task.Delay(700);
                    var response = await httpClient.SendAsync(requestMessage);

                    if (!response.IsSuccessStatusCode)
                    {
                        if (response.StatusCode == HttpStatusCode.Unauthorized)
                        {
                            var token = await _tokenHandler.CreateTokenAsync();
                            return await RequestAsync(requestMessage);
                        }
                    }
                    return response;
                }
                else
                {
                    var token = await _tokenHandler.CreateTokenAsync();
                    return await RequestAsync(requestMessage);
                }

            }
            catch (Exception ex)
            {
                return null;
            }

        }
    }

}
