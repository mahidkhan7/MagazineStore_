﻿using MagazineStore.Domain.Common;
using MagazineStore.Infrastructure.Configuration;
using MagazineStore.Infrastructure.Interface;
using MagazineStore.Infrastructure.Services.Security;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace MagazineStore.Infrastructure.Services
{
    public class MagazineAPI : BaseAPIService, IMagazineAPI
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IOptions<MagazineConfig> _configSetting;
        StringContent requestData;
        HttpResponseMessage responseMessage;
        string responseResult;
        public MagazineAPI(IHttpClientFactory httpClientFactory, IOptions<MagazineConfig> configSetting, ITokenHandler tokenHandler) : base(httpClientFactory, tokenHandler)
        {
            _httpClientFactory = httpClientFactory;
            _configSetting = configSetting;
        }
        public async Task<IResponseEntity> MagazineApiOperation(string URL, string verb, object model)
        {

            System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12 | System.Net.SecurityProtocolType.Tls13;
          
            if (verb.Equals("POST", StringComparison.InvariantCultureIgnoreCase))
            {
                if (model != null)
                {
                    var json = JsonConvert.SerializeObject(model);
                    requestData = new StringContent(json, Encoding.UTF8, "application/json");
                }
                HttpRequestMessage request = new HttpRequestMessage
                {
                    Method = HttpMethod.Post,
                    RequestUri = new Uri(URL),
                    Content = requestData
                };
                responseMessage = await RequestAsync(request);
                responseResult = await responseMessage.Content.ReadAsStringAsync();
                return new ResponseEntiry(responseMessage.StatusCode == System.Net.HttpStatusCode.OK ? "Success" : "Fail", responseResult);
            }
            else if (verb.Equals("GET", StringComparison.InvariantCultureIgnoreCase))
            {
                if (model != null)
                {
                    var json = JsonConvert.SerializeObject(model);
                    requestData = new StringContent(json, Encoding.UTF8, "application/json");
                }
                HttpRequestMessage request = new HttpRequestMessage
                {
                    Method = HttpMethod.Get,
                    RequestUri = new Uri(URL),
                    Content = requestData
                };
                responseMessage = await RequestAsync(request);
                responseResult = await responseMessage.Content.ReadAsStringAsync();
                return new ResponseEntiry(responseMessage.StatusCode == System.Net.HttpStatusCode.OK ? "Success" : "Fail", responseResult);
            }
            return new ResponseEntiry();

        }
    }
}
