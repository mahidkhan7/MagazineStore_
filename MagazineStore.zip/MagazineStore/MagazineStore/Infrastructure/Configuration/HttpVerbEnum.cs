﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace MagazineStore.Infrastructure.Configuration
{
   public enum HttpVerbEnum
    {
        [Description("GET")]
        GET,
        [Description("PUT")]
        PUT,
        [Description("POST")]
        POST,
        [Description("DEL")]
        DELETE,
    }
}
