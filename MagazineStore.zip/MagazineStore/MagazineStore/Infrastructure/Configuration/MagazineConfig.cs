﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MagazineStore.Infrastructure.Configuration
{
    public class MagazineConfig
    {
        public string BaseURL { get; set; }
        public string GenerateTokenURL { get; set; }
        public string CategoriesURL { get; set; }
        public string MagazinesByCategoryURL { get; set; }
        public string SubscriberURL { get; set; }
        public string AnswerURL { get; set; }


    }
}
