﻿using MagazineStore.Domain.Common;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MagazineStore.Infrastructure.Interface
{
   public interface IMagazineAPI
    {
        Task<IResponseEntity> MagazineApiOperation(string URL, string verb, object model);
    }
}
